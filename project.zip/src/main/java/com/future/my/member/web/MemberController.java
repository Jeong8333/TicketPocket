package com.future.my.member.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.future.my.common.valid.Regist;
import com.future.my.member.service.MemberService;
import com.future.my.member.vo.MemberVO;


@Controller
public class MemberController {
	
	@Value("#{util['file.upload.path']}")
	private String CURR_IMAGE_PATH;
	
	@Value("#{util['file.download.path']}")
	private String WEB_PATH;
	
	@Autowired
	MemberService memberService;
	
	/**
	 * Class Name  : MemberController
	 * Author      : ShinMiJeong
	 * Created Date: 2025. 4. 7.
	 * Version: 1.0
	 * Purpose: 로그인 
	 * Description: 로그인
	 */
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@RequestMapping("/loginView")
	public String loginView() {
		return "member/loginView";
	}
	
	@RequestMapping("/loginDo")
	public String loginDo(MemberVO vo, HttpSession session, boolean remember, HttpServletResponse res) throws Exception {
		MemberVO user = null;
		user = memberService.loginMember(vo);
		boolean match = passwordEncoder.matches(vo.getMemPw(),user.getMemPw());
		if(user == null || !match) {
			return "redirect:/loginView";
		}
		session.setAttribute("login", user);
		// 쿠키 생성
		if(remember) {
			Cookie cookie = new Cookie("rememberId", user.getMemId());
			res.addCookie(cookie);
		}else {
			Cookie cookie = new Cookie("rememberId", "");
			cookie.setMaxAge(0);
			res.addCookie(cookie);
		}
		return "redirect:/";
	}
	
	/**
	 * Class Name  : MemberController
	 * Author      : ShinMiJeong
	 * Created Date: 2025. 4. 7.
	 * Version: 1.0
	 * Purpose: 로그인 
	 * Description: 로그아웃
	 */
	@RequestMapping("/logoutDo")
	public String logoutDo(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	/**
	 * Class Name  : MemberController
	 * Author      : ShinMiJeong
	 * Created Date: 2025. 4. 7.
	 * Version: 1.0
	 * Purpose: 회원가입 
	 * Description: 
	 */
	
	@RequestMapping("/registView")
	public String registView() {
		return "member/registView";
	}
	@RequestMapping("/registDo")
	public String registDo(Model model
						, @Validated(Regist.class) @ModelAttribute("member")MemberVO member
						, BindingResult result) {
		System.out.println(member);
		if(result.hasErrors()) {
			return "home";
		}
		
		try {
			member.setMemPw(passwordEncoder.encode(member.getMemPw()));
			memberService.registMember(member);
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("member", new MemberVO());
			System.out.println(e);
			return "member/registView";
		}
				
		return "home";
	}
	//프로필 수정으로
	@RequestMapping("/profile")
	public String profile(HttpSession session, Model model) {
		System.out.println(CURR_IMAGE_PATH);
		if(session.getAttribute("login") == null) {
			return "redirect:loginView";
		}
		return "member/profile";
	}
	//프로필 이미지 변경
	@ResponseBody
	@PostMapping("/files/upload")
	public Map<String,Object> uploadFiles(HttpSession session,
										@RequestParam("uploadImage") MultipartFile file) throws Exception{
		MemberVO vo = (MemberVO)session.getAttribute("login");
		System.out.println(file);
		String imgPath = memberService.profileUpload(vo, CURR_IMAGE_PATH, WEB_PATH, file);
		Map<String, Object> map = new HashMap<>();
		map.put("message", "success");
		map.put("imagePath", imgPath);
		return map;
	}
}
