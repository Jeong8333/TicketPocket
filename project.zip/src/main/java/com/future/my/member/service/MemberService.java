package com.future.my.member.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.future.my.member.dao.IMemberDAO;
import com.future.my.member.vo.MemberVO;

@Service
public class MemberService {

	@Autowired
	IMemberDAO dao;
	
	public void registMember(MemberVO vo) throws DuplicateKeyException
												,DataAccessException
												,Exception {
		int result = dao.registMember(vo);
		if(result == 0 ) {
		throw new Exception();
		}
	}
	
	public MemberVO loginMember(MemberVO vo) throws Exception{
		MemberVO user = dao.loginMember(vo);
		System.out.print(user);
		if(user == null) {
			throw new Exception();
		}
		return user;
	}
	
	public String profileUpload(MemberVO vo	, String uploadDir,String webPath, MultipartFile file) throws Exception {	
		String origin = file.getOriginalFilename();
		String unique = UUID.randomUUID().toString() + "_" + origin;
		String dbPath = webPath + unique; 
		Path filePath = Paths.get(uploadDir, unique);
		try {
			Files.copy(file.getInputStream(), filePath);
		} catch (IOException e) {
			throw new Exception("file to save the title", e);
		}
		vo.setProfileImg(dbPath);
		int result = dao.profileUpload(vo);
		if(result == 0) {
			throw new Exception();
		}
			return dbPath;
		}
}
