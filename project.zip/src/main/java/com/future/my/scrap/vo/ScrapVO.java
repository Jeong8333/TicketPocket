package com.future.my.scrap.vo;

public class ScrapVO {
	
	private int scrapNo;
	private String memId;
	private String title;
	private String viewingDate;
	private String ticketImg;
	private String useYn;

	
	public ScrapVO() {
	}


	public int getScrapNo() {
		return scrapNo;
	}


	public void setScrapNo(int scrapNo) {
		this.scrapNo = scrapNo;
	}


	public String getMemId() {
		return memId;
	}


	public void setMemId(String memId) {
		this.memId = memId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public final String getViewingDate() {
		return viewingDate;
	}


	public final void setViewingDate(String viewingDate) {
		this.viewingDate = viewingDate;
	}


	public String getTicketImg() {
		return ticketImg;
	}


	public void setTicketImg(String ticketImg) {
		this.ticketImg = ticketImg;
	}


	public String getUseYn() {
		return useYn;
	}


	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}


	@Override
	public String toString() {
		return "ScrapVO [scrapNo=" + scrapNo + ", memId=" + memId + ", title=" + title + ", viewingDate=" + viewingDate
				+ ", ticketImg=" + ticketImg + ", useYn=" + useYn + "]";
	}


	

}
