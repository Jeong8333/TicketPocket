package com.future.my.scrap.service;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.future.my.scrap.dao.IScrapDAO;
import com.future.my.scrap.vo.ScrapVO;

@Service
public class ScrapService {
	
	@Autowired
	IScrapDAO dao;
	
	// 티켓북 DB 저장
	public void insertScrap(ScrapVO vo) throws Exception {
		int result = dao.insertScrap(vo);
		if(result == 0) {
			throw new Exception();
		}
	}
	
	// DB 조회
	public List<ScrapVO> getScrap(String memId){
		List<ScrapVO> scrap = dao.getScrap(memId);
		return scrap != null ? scrap : Collections.emptyList();
	}
	
	// 삭제
	public void deleteScrap(int scrapNo) throws Exception {
		int result = dao.deleteScrap(scrapNo);
		if(result == 0) {
			throw new Exception();
		}
		
	}
}
