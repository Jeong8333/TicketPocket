package com.future.my.scrap.web;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.future.my.member.vo.MemberVO;
import com.future.my.scrap.service.ScrapService;
import com.future.my.scrap.vo.ScrapVO;

@Controller
public class ScrapController {
	
	@Autowired
	ScrapService scrapService;
	
	// 스크랩 북 페이지 이동 및 DB 조회
	@GetMapping("/bookView") // 스크랩북 접근 URL 경로 정의
    public String bookView(@SessionAttribute(name = "login", required = false) MemberVO login, Model model, HttpSession session) {
        if (login == null) {
            return "redirect:/loginView"; 
        }
        String memId = login.getMemId();
        List<ScrapVO> scrapList = scrapService.getScrap(memId);
        model.addAttribute("scrapList", scrapList);
        return "scrap/bookView"; 
    }
	
	@Autowired
	private ServletContext servletContext;

	//티켓북 DB 저장
	@PostMapping("/scrapInsertDo")
	public String scrapInsertDo(@ModelAttribute ScrapVO vo,
	                            @RequestParam("ticketImgBase64") String base64Img,
	                            HttpServletRequest request) throws Exception {
	    
	    if (base64Img != null && base64Img.startsWith("data:image")) {
	        // Base64 추출
	        String base64Data = base64Img.substring(base64Img.indexOf(",") + 1);
	        byte[] imageBytes = Base64.getDecoder().decode(base64Data);

	        // 저장 경로 생성
	        String uploadDir = servletContext.getRealPath("/resources/upload/");
	        File dir = new File(uploadDir);
	        if (!dir.exists()) dir.mkdirs();

	        // 저장 파일명 생성
	        String filename = UUID.randomUUID() + ".jpg";
	        File imageFile = new File(uploadDir, filename);

	        // 저장
	        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
	            fos.write(imageBytes);
	        }
	        vo.setTicketImg("/resources/upload/" + filename);
	    }

	    scrapService.insertScrap(vo);
		return "redirect:/bookView";
	}
	
	// 삭제
	@PostMapping("/scrapDeleteDo")
	public String scrapDeleteDo(int scrapNo) throws Exception {
		scrapService.deleteScrap(scrapNo);
		return "redirect:/bookView";
	}


	
}
