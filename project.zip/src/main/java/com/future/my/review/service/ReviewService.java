package com.future.my.review.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.future.my.review.dao.IReviewDAO;
import com.future.my.review.vo.ReviewCategorySearchVO;
import com.future.my.review.vo.ReviewListSearchVO;
import com.future.my.review.vo.ReviewVO;

@Service
public class ReviewService {

	@Autowired
	IReviewDAO dao;
	
	
	public ArrayList<ReviewVO> getReviewList(ReviewListSearchVO searchVO){
		int totalRowCount = dao.getTotalRowCount(searchVO);
		searchVO.setTotalRowCount(totalRowCount);
		searchVO.pageSetting();
		return dao.getReviewList(searchVO);
	}
	
	
	public ReviewVO getReview(int reviewNo) throws Exception {
		ReviewVO review = dao.getReview(reviewNo);
		if(review == null) {
			throw new Exception();
		}
		return review;
	}
	
	
	// 항목별 공연 데이터 조회
	public ArrayList<ReviewVO> getCultureList(ReviewCategorySearchVO searchVO){
		return dao.getCultureList(searchVO);
	}
	// 후기글 작성
	public void insertReview(ReviewVO vo) throws Exception {
		int result = dao.insertReview(vo);
		if(result == 0) {
			throw new Exception();
		}
	}
	
	// 후기글 수정
	public void updateReview(ReviewVO review) throws Exception {
		int result = dao.updateReview(review);
		if(result == 0) {
			throw new Exception();
		}
	}
	
	// 후기글 삭제
	public void deleteReview(int reviewNo) throws Exception {
		int result = dao.deleteReview(reviewNo);
		if(result == 0) {
			throw new Exception();
		}
	}
	
}
