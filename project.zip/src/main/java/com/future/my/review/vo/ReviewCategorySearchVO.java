package com.future.my.review.vo;

public class ReviewCategorySearchVO {
	private String searchWord;	   /* 검색 키워드 */
	private String searchCategory; /* 분류 항목 */
	
	public ReviewCategorySearchVO() {
	}

	public String getSearchWord() {
		return searchWord;
	}

	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}

	public String getSearchCategory() {
		return searchCategory;
	}

	public void setSearchCategory(String searchCategory) {
		this.searchCategory = searchCategory;
	}

	@Override
	public String toString() {
		return "ReviewCategorySearchVO [searchWord=" + searchWord + ", searchCategory=" + searchCategory + "]";
	}

}
