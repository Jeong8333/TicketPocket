package com.future.my.review.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.future.my.review.vo.ReviewCategorySearchVO;
import com.future.my.review.vo.ReviewListSearchVO;
import com.future.my.review.vo.ReviewVO;

@Mapper
public interface IReviewDAO {
	
	// 페이징 처리
	// 전체 건수
	public int getTotalRowCount(ReviewListSearchVO searchVO);
	// 목록 조회
	public ArrayList<ReviewVO> getReviewList(ReviewListSearchVO searchVO);
	
	// 리뷰 작성
	public int insertReview(ReviewVO vo);
	// 항목별 공연 데이터 조회
	public ArrayList<ReviewVO> getCultureList(ReviewCategorySearchVO searchVO);
	
	// 후기글 불러오기
	public ReviewVO getReview(int reviewNo);
	// 후기글 수정
	public int updateReview(ReviewVO Review);
	// 후기글 삭제
	public int deleteReview(int reviewNo);
	
	

}
