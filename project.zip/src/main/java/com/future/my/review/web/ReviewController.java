package com.future.my.review.web;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.future.my.common.service.CodeService;
import com.future.my.common.vo.CodeVO;
import com.future.my.member.vo.MemberVO;
import com.future.my.review.service.ReviewService;
import com.future.my.review.vo.ReviewCategorySearchVO;
import com.future.my.review.vo.ReviewListSearchVO;
import com.future.my.review.vo.ReviewVO;



@Controller
@RequestMapping("/review")
public class ReviewController {
	
	//분야 선택 option
	@Autowired
	CodeService codeService;
	
	@ModelAttribute("comMainList")
	public ArrayList<CodeVO> comMainList(){
		return codeService.getCodeList(null);  //test
	}
	
	@Autowired
	ReviewService reviewService;
	
	// 리뷰 작성 페이지로 이동
	@RequestMapping("/reviewWriteView")
	public String reviewWriteView() {
		return "review/reviewWriteView";
	}
	
	// 리뷰 작성폼
	@PostMapping("/reviewWriteDo")
	public String reviewWriteDo(ReviewVO vo) throws Exception{
		System.out.println(vo);
		reviewService.insertReview(vo);
		return "redirect:/review/mypage";
	}
		
	//검색&리스트 출력
	@ResponseBody
	@PostMapping("/cultureDo")
	public ArrayList<ReviewVO> cultureDo(ReviewCategorySearchVO searchVO) {
		System.out.println(searchVO);
		ArrayList<ReviewVO> cultureList = reviewService.getCultureList(searchVO);
		return cultureList;
	}
	
	// 마이페이지-저장된 리뷰의 포스터 정렬
	@RequestMapping("/mypage")
	public String reviewList(HttpSession session
						  ,Model model
						  ,@ModelAttribute("searchVO") ReviewListSearchVO searchVO) {
		MemberVO loginMember = (MemberVO) session.getAttribute("login");
		if (loginMember != null) {
			searchVO.setMemId(loginMember.getMemId());
			ArrayList<ReviewVO> reviewList = reviewService.getReviewList(searchVO);
			model.addAttribute("reviewList", reviewList);
		} else {
			 return "redirect:/loginView"; 
		}
		return "/review/mypage";
	}
	
	// 저장된 기록 페이지
	@RequestMapping("/reviewView")
	public String reviewView(Model model, int reviewNo) throws Exception {
		ReviewVO review= reviewService.getReview(reviewNo);
		model.addAttribute("review", review);
		return "review/reviewView";
	}
	
	// 기록 수정
	@RequestMapping("/reviewUpdateDo")
	public String reviewUpdateDo(ReviewVO review) throws Exception {
		reviewService.updateReview(review);
		return "redirect:/review/mypage";
	}
	
	// 기록 삭제
	@PostMapping("/reviewDeleteDo")
	public String reviewDeleteDo(int reviewNo) throws Exception {
		reviewService.deleteReview(reviewNo);
		return "redirect:/review/mypage";
	}
}
