package com.future.my.review.vo;

public class ReviewVO {
	
	private int    reviewNo;         /* 게시글 번호 */
	private String memId;            /* 회원 id */
	private int    ticketNo;         /* 인터파크 티켓 테이블 id */
	private int    cultureNo;        /* 문화 테이블 id */
	private String commCd;         /* 분류코드 */
	private String commNm;         /* 분류 항목 */
	private String title;            /* 공연명 */
	private String poster;           /* 이미지(썸네일) 주소 */
	private String addr;             /* 장소  */
	private String viewingDate;      /* 관람일 */
	private String reviewDate;       /* 작성일 */
	private String updateDate;       /* 수정일  */
	private String friend;           /* 동행인 */
	private float  rating;           /* 별점 */
	private String review;           /* 관람평 */
	private String photo;            /* 첨부 사진 경로 */
	private String delYn;            /* 삭제 여부(Y 또는 N) 기본값 : N*/
	private String searchCategory;   /* 분류 항목 */
	
	public String getCommCd() {
		return commCd;
	}


	public void setCommCd(String commCd) {
		this.commCd = commCd;
	}


	public String getCommNm() {
		return commNm;
	}


	public void setCommNm(String commNm) {
		this.commNm = commNm;
	}


	@Override
	public String toString() {
		return "ReviewVO [reviewNo=" + reviewNo + ", memId=" + memId + ", ticketNo=" + ticketNo + ", cultureNo="
				+ cultureNo + ", commCd=" + commCd + ", commNm=" + commNm + ", title=" + title + ", poster=" + poster
				+ ", addr=" + addr + ", viewingDate=" + viewingDate + ", reviewDate=" + reviewDate + ", updateDate="
				+ updateDate + ", friend=" + friend + ", rating=" + rating + ", review=" + review + ", photo=" + photo
				+ ", delYn=" + delYn + ", searchCategory=" + searchCategory + "]";
	}


	public ReviewVO() {
	}


	public int getReviewNo() {
		return reviewNo;
	}

	public void setReviewNo(int reviewNo) {
		this.reviewNo = reviewNo;
	}

	public String getMemId() {
		return memId;
	}

	public void setMemId(String memId) {
		this.memId = memId;
	}

	public int getTicketNo() {
		return ticketNo;
	}

	public void setTicketNo(int ticketNo) {
		this.ticketNo = ticketNo;
	}

	public int getCultureNo() {
		return cultureNo;
	}

	public void setCultureNo(int cultureNo) {
		this.cultureNo = cultureNo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPoster() {
		return poster;
	}

	public void setPoster(String poster) {
		this.poster = poster;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getViewingDate() {
		return viewingDate;
	}

	public void setViewingDate(String viewingDate) {
		this.viewingDate = viewingDate;
	}

	public String getReviewDate() {
		return reviewDate;
	}

	public void setReviewDate(String reviewDate) {
		this.reviewDate = reviewDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getFriend() {
		return friend;
	}

	public void setFriend(String friend) {
		this.friend = friend;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getDelYn() {
		return delYn;
	}

	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}

	public String getSearchCategory() {
		return searchCategory;
	}

	public void setSearchCategory(String searchCategory) {
		this.searchCategory = searchCategory;
	}



	


}
