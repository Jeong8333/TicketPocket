package com.future.my.stats.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.future.my.stats.dao.IStatsDAO;
import com.future.my.stats.vo.StatsVO;

@Service
public class StatsService {
	
	@Autowired
	IStatsDAO dao;

	// 월별 통계
	public ArrayList<StatsVO> getMonthlyCount(String memId){
		return dao.getMonthlyCount(memId);
	}
	
	// 장르별 통계
	public ArrayList<StatsVO> getGenreCount(String memId){
		return dao.getGenreCount(memId);
	}

}
