package com.future.my.stats.vo;

public class StatsVO {
	
	private int    reviewNo;
	private String memId;
	private String commName;
	private String viewingDate; 
	private String delYn;  
    private int month;
    private int count;
	
	public StatsVO() {
	}

	public int getReviewNo() {
		return reviewNo;
	}

	public void setReviewNo(int reviewNo) {
		this.reviewNo = reviewNo;
	}

	public String getMemId() {
		return memId;
	}

	public void setMemId(String memId) {
		this.memId = memId;
	}

	public String getCommName() {
		return commName;
	}

	public void setCommName(String commName) {
		this.commName = commName;
	}

	public String getViewingDate() {
		return viewingDate;
	}

	public void setViewingDate(String viewingDate) {
		this.viewingDate = viewingDate;
	}

	public String getDelYn() {
		return delYn;
	}

	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "StatsVO [reviewNo=" + reviewNo + ", memId=" + memId + ", commName=" + commName + ", viewingDate="
				+ viewingDate + ", delYn=" + delYn + ", month=" + month + ", count=" + count + "]";
	}

	
	
	
}
