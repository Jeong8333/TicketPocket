package com.future.my.member.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.future.my.member.dao.IMemberDAO;
import com.future.my.member.vo.MemberVO;

@Service
public class MemberService {

	@Autowired
	IMemberDAO dao;
	
	@Autowired // ⭐ BCryptPasswordEncoder 주입
    private BCryptPasswordEncoder passwordEncoder;
	
	public void registMember(MemberVO vo) throws DuplicateKeyException
												,DataAccessException
												,Exception {
		int result = dao.registMember(vo);
		if(result == 0 ) {
		throw new Exception();
		}
	}
	
	public MemberVO loginMember(MemberVO vo) throws Exception{
		MemberVO user = dao.loginMember(vo);
		System.out.print(user);
		if(user == null) {
			throw new Exception();
		}
		return user;
	}
	
	// 프로필 이미지 수정
	public String profileUpload(MemberVO vo	, String uploadDir,String webPath, MultipartFile file) throws Exception {	
		String origin = file.getOriginalFilename();
		String unique = UUID.randomUUID().toString() + "_" + origin;
		String dbPath = webPath + unique; 
		Path filePath = Paths.get(uploadDir, unique);
		try {
			Files.copy(file.getInputStream(), filePath);
		} catch (IOException e) {
			throw new Exception("file to save the title", e);
		}
		vo.setProfileImg(dbPath);
		int result = dao.profileUpload(vo);
		if(result == 0) {
			throw new Exception();
		}
			return dbPath;
	}
	
	// 비밀번호 변경 기능 추가 
    public boolean changePassword(MemberVO loginMember, String currentMemPw, String newMemPw) throws Exception {
        // 1. 현재 비밀번호 확인
        // 사용자가 입력한 currentMemPw와 DB에 저장된 암호화된 비밀번호(loginMember.getMemPw())를 비교합니다.
        // BCryptPasswordEncoder의 matches() 메서드를 사용해야 합니다.
        if (!passwordEncoder.matches(currentMemPw, loginMember.getMemPw())) {
            return false; // 현재 비밀번호 불일치
        }

        // 2. 새로운 비밀번호를 암호화
        String encodedNewPw = passwordEncoder.encode(newMemPw);

        // 3. MemberVO에 새로운 암호화된 비밀번호 설정
        loginMember.setMemPw(encodedNewPw);

        // 4. DAO 호출하여 DB 업데이트
        // profileUpload DAO 메서드가 mem_pw도 업데이트하도록 되어 있으므로 재활용합니다.
        // 이때 profileImg 값은 loginMember 객체에 있는 기존 값이 그대로 전달되어 이미지 변경 없이 비밀번호만 업데이트됩니다.
        int result = dao.profileUpload(loginMember);

        return result > 0;
    }
}
