package com.future.my.stats.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.future.my.stats.vo.StatsVO;


@Mapper
public interface IStatsDAO {
	
	// 월별 통계
	public ArrayList<StatsVO> getMonthlyCount(String memId);
	
	// 장르별 통계
	public ArrayList<StatsVO> getGenreCount(String memId);

}
