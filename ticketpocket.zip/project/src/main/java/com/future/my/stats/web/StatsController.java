package com.future.my.stats.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.future.my.stats.service.StatsService;
import com.future.my.stats.vo.StatsVO;

@Controller
@RequestMapping("/stats")
public class StatsController {

	@RequestMapping("/statsView")
	public String statsView() {
		return "stats/statsView";
	}
	
	@Autowired
	StatsService statsService;
	
	@GetMapping("/monthly")
	@ResponseBody
	public Map<String, Object> getMonthlyStats(@RequestParam("memId") String memId) {
		ArrayList<StatsVO> monthlyStats = statsService.getMonthlyCount(memId);
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("monthlyStats", monthlyStats);
        return result;
    }
	
    // 장르별 기록 수 조회
    @GetMapping("/genre")
    @ResponseBody
    public Map<String, Object> getGenreStats(@RequestParam("memId") String memId) {
        ArrayList<StatsVO> genreStats = statsService.getGenreCount(memId);
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("genreStats", genreStats);
        return result;
    }
}
