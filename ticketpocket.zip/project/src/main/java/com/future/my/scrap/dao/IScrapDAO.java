package com.future.my.scrap.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.future.my.scrap.vo.ScrapVO;

@Mapper
public interface IScrapDAO {

	//티켓북 DB 저장
	public int insertScrap(ScrapVO vo);
	
	//DB 조회
	public List<ScrapVO> getScrap(@Param("memId") String memId);
	
	//삭제
	public int deleteScrap(int scrapNo);
	
	
}
