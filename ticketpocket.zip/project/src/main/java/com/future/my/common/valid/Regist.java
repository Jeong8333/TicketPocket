package com.future.my.common.valid;

public interface Regist {

}
