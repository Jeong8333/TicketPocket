package com.future.my.member.vo;


import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.future.my.common.valid.Regist;

/**
 * Class Name  : MemberVO
 * Author      : ShinMiJeong
 * Created Date: 2025. 4. 4.
 * Version: 1.0
 * Purpose: 회원 정보
 * Description: 회원 정보 관리
 */
public class MemberVO {
	
	@NotEmpty(message="아이디 필수!!", groups= {Regist.class})
	@Size(min=6, max=20, message="아이디 6~20 자 이내로", groups={Regist.class})
	private String memId;         /* 아이디 */
	
	@Pattern(regexp="^\\w{8,20}$", message="비밀번호는 영문, 숫자, 특수문자 포함 8~20자", groups={Regist.class})
	private String memPw;         /* 비밀번호*/
	
	@Size(min=1, max=10, message="이름 10자 이내로", groups={Regist.class})
	private String memNm;         /* 이름 */
	
	@Size(min=2, max=20, message="닉네임 2~10자 이내로", groups={Regist.class})
	private String memNick;       /* 닉네임 */
	
	private String memAddr;      /* 이메일 주소 */
	private String profileImg;   /* 프로필 이미지 경로 */
	private String createDate;   /* 가입 날짜 */
	private String updateDate;   /* 수정 날짜 */
	private String useYn;        /* 사용 여부(Y or N)*/
	
	public MemberVO() {
	}

	public String getMemId() {
		return memId;
	}

	public void setMemId(String memId) {
		this.memId = memId;
	}

	public String getMemPw() {
		return memPw;
	}

	public void setMemPw(String memPw) {
		this.memPw = memPw;
	}

	public String getMemNm() {
		return memNm;
	}

	public void setMemNm(String memNm) {
		this.memNm = memNm;
	}

	public String getMemNick() {
		return memNick;
	}

	public void setMemNick(String memNick) {
		this.memNick = memNick;
	}

	public String getMemAddr() {
		return memAddr;
	}

	public void setMemAddr(String memAddr) {
		this.memAddr = memAddr;
	}

	public String getProfileImg() {
		return profileImg;
	}

	public void setProfileImg(String profileImg) {
		this.profileImg = profileImg;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	@Override
	public String toString() {
		return "MemberVO [memId=" + memId + ", memPw=" + memPw + ", memNm=" + memNm + ", memNick=" + memNick
				+ ", memAddr=" + memAddr + ", profileImg=" + profileImg + ", createDate=" + createDate + ", updateDate="
				+ updateDate + ", useYn=" + useYn + "]";
	}

	

}
